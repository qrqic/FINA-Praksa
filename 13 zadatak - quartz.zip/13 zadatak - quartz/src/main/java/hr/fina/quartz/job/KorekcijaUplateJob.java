package hr.fina.quartz.job;

import hr.fina.quartz.repository.KorekcijaRepository;
import org.quartz.JobExecutionContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Component
public class KorekcijaUplateJob extends QuartzJobBean {

    private static final Logger log = LoggerFactory.getLogger(KorekcijaUplateJob.class);
    private final KorekcijaRepository repository;

    public KorekcijaUplateJob(KorekcijaRepository repository) {
        this.repository = repository;
    }

    @Override
    protected void executeInternal(JobExecutionContext context) {
        // 1. Inicijalizacija na vrhu - dostupno svuda
        LocalDateTime trenutnoVrijemeDo = LocalDateTime.now();
        LocalDateTime vrijemeOd = null;

        try {
            String status = repository.dohvatiVrijednostParametra("KOREKCIJA_STATUS");

            if ("ON".equalsIgnoreCase(status)) {
                BigDecimal noviIznos = new BigDecimal(repository.dohvatiVrijednostParametra("KOREKCIJSKI_IZNOS"));

                // 2. Dohvat vremena
                vrijemeOd = repository.dohvatiZadnjeUspjesnoVrijemeDo();
                if (vrijemeOd == null) {
                    vrijemeOd = LocalDateTime.now().minusDays(1);
                }

                // 3. Akcije u bazi
                repository.arhivirajPrijeKorekcije(noviIznos, vrijemeOd);
                repository.izvrsiKorekciju(noviIznos, vrijemeOd);

                // 4. Logiranje uspjeha
                repository.logirajJob(vrijemeOd, trenutnoVrijemeDo, "SUCCESS");
                log.info("Job odradio uspješno.");
            }
        } catch (Exception e) {
            log.error("Greška: ", e);
            try {
                LocalDateTime odZaLog = (vrijemeOd != null) ? vrijemeOd : trenutnoVrijemeDo;
                repository.logirajJob(odZaLog, trenutnoVrijemeDo, "FAILED");
            } catch (Exception ex) {
                log.error("Neuspjelo logiranje greške.");
            }
        }
    }
}
