package hr.fina.quartz.repository;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Mapper
@Repository
public interface KorekcijaRepository {

    // Dohvaća vrijednost (npr. ON/OFF ili iznos) iz parametri_sustava
    String dohvatiVrijednostParametra(@Param("kljuc") String kljuc);

    // Dohvaća zadnji uspješan kraj posla za 'vrijeme_od' novog kruga
    LocalDateTime dohvatiZadnjeUspjesnoVrijemeDo();

    // Logira izvršenje u job_log tablicu
// Promijeni 'do' u 'kraj' ili 'vrijemeDo'
    void logirajJob(@Param("vrijemeOd") LocalDateTime od,
                    @Param("vrijemeDo") LocalDateTime kraj, // Ovdje je bila greška
                    @Param("status") String status);


    // Prvi korak: Kopiranje podataka u arhivu (prije UPDATE-a)
    void arhivirajPrijeKorekcije(@Param("noviIznos") BigDecimal noviIznos,
                                 @Param("vrijemeOd") LocalDateTime granica);

    // Drugi korak: Update samih naloga
    void izvrsiKorekciju(@Param("noviIznos") BigDecimal noviIznos,
                         @Param("vrijemeOd") LocalDateTime granica);
}
