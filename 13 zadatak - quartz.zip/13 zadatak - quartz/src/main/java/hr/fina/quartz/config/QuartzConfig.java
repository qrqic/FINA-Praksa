package hr.fina.quartz.config;

import hr.fina.quartz.job.KorekcijaUplateJob;
import org.quartz.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class QuartzConfig {

    @Bean
    public JobDetail korekcijaJobDetail() {
        return JobBuilder.newJob(KorekcijaUplateJob.class)
                .withIdentity("korekcijaJob")
                .storeDurably()
                .build();
    }

    @Bean
    public Trigger korekcijaJobTrigger() {

        return TriggerBuilder.newTrigger()
                .forJob(korekcijaJobDetail())
                .withIdentity("korekcijaTrigger")
                .withSchedule(CronScheduleBuilder.cronSchedule("10 */10 * * * ?"))
                .build();
    }
}
