package hr.fina.gen.config;

import hr.fina.gen.job.PaymentGeneratorJob;
import org.quartz.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class QuartzConfig {

    @Bean
    public JobDetail korekcijaJobDetail() {
        return JobBuilder.newJob(PaymentGeneratorJob.class)
                .withIdentity("korekcijaJob")
                .storeDurably()
                .build();
    }

    @Bean
    public Trigger korekcijaJobTrigger() {

        return TriggerBuilder.newTrigger()
                .forJob(korekcijaJobDetail())
                .withIdentity("korekcijaTrigger")
                .withSchedule(CronScheduleBuilder.cronSchedule("0 */10 * * * ?"))
                .build();
    }
}
