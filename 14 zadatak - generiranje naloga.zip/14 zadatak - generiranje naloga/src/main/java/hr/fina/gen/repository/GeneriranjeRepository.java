package hr.fina.gen.repository;

import hr.fina.gen.model.Payment;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface GeneriranjeRepository {

    // Dohvaća listu svih naloga
    List<Payment> dohvatiSve();

    // Nalazi jedan nalog po ID-u
    Payment findById(@Param("id") String id);

    // Briše nalog iz baze
    void izbrisiKorisnika(@Param("id") String id);

    // Ažurira podatke naloga (koristi objekt Payment)
    void azurirajTablicu(Payment payment);

    // Glavna metoda za generator: spremanje novog naloga
    void save(Payment payment);

    // Dohvaća postavke generatora (ON/OFF, broj naloga, itd.)
    String dohvatiVrijednostParametra(@Param("kljuc") String kljuc);

    // Admin metoda za promjenu postavki generatora
    void updateParametar(@Param("kljuc") String kljuc, @Param("vrijednost") String vrijednost);
}
