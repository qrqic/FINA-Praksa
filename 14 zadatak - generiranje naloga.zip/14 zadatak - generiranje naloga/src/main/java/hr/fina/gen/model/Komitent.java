package hr.fina.gen.model;

public class Komitent {
    private String name;
    private String iban;

    public Komitent() {}

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getIban() { return iban; }
    public void setIban(String iban) { this.iban = iban; }
}
