package hr.fina.gen.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class Payment {

    private String transactionId;
    private BigDecimal amount;
    private String currency;
    private LocalDateTime timestamp;
    private Komitent payer;
    private Komitent payee;

    public Payment() {
        this.payer = new Komitent();
        this.payee = new Komitent();
    }

    // Pomoćne metode za Generator da kod u Job-u ostane kratak
    public void setPayerName(String name) { this.payer.setName(name); }
    public void setPayerIban(String iban) { this.payer.setIban(iban); }
    public void setPayeeName(String name) { this.payee.setName(name); }
    public void setPayeeIban(String iban) { this.payee.setIban(iban); }

    // Standardni Getteri i Setteri
    public String getTransactionId() { return transactionId; }
    public void setTransactionId(String transactionId) { this.transactionId = transactionId; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }

    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    public Komitent getPayer() { return payer; }
    public void setPayer(Komitent payer) { this.payer = payer; }

    public Komitent getPayee() { return payee; }
    public void setPayee(Komitent payee) { this.payee = payee; }
}
