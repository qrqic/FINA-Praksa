package hr.fina.gen.job;

import hr.fina.gen.model.Payment;
import hr.fina.gen.repository.GeneriranjeRepository;
import org.quartz.JobExecutionContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.Random;

@Component
public class PaymentGeneratorJob extends QuartzJobBean {

    @Autowired
    private GeneriranjeRepository generiranjeRepository;

    private final Random random = new Random();

    private static final Logger log = LoggerFactory.getLogger(PaymentGeneratorJob.class);


    @Override
    protected void executeInternal(JobExecutionContext context) {
        // 1. Dohvati Admin postavke iz baze
        int brojNaloga = Integer.parseInt(generiranjeRepository.dohvatiVrijednostParametra("GEN_BROJ_NALOGA"));
        int stopaGreske = Integer.parseInt(generiranjeRepository.dohvatiVrijednostParametra("GEN_STOPA_GRESKE"));

        log.info("Započeto generiranje {} naloga (Stopa greške: {}%)", brojNaloga, stopaGreske);

        for (int i = 0; i < brojNaloga; i++) {
            //  GENERIRANJE NALOGA
            Payment nalog = new Payment();

            String noviId;
            boolean postoji;
            do {
                noviId = "TX" + (100000 + random.nextInt(900000));
                postoji = (generiranjeRepository.findById(noviId) != null);
            } while (postoji);

            nalog.setTransactionId(noviId);
            nalog.setAmount(BigDecimal.valueOf(50 + (random.nextDouble() * 150)).setScale(2, RoundingMode.HALF_UP));
            nalog.setCurrency("EUR");
            nalog.setTimestamp(LocalDateTime.now());
            nalog.setPayerName(getRandomName());
            nalog.setPayerIban(getRandomIban());
            nalog.setPayeeName(getRandomName());
            nalog.setPayeeIban(getRandomIban());

            // SIMULACIJA GREŠKE KOD POKUŠAJA SPREMANJA
            if (random.nextInt(100) < stopaGreske) {
                // Logiramo da je nalog pripremljen, ali simuliramo pad pri upisu
                log.error(">>> GREŠKA: Nalog {} je uspješno kreiran, ali je odbijen (Simulacija greške pri upisu)!", nalog.getTransactionId());
                continue;
            }

            // USPJEŠNO SPREMANJE
            generiranjeRepository.save(nalog);
            log.info("+++ USPJEH: Nalog {} za komitenta {} uspješno spremljen u bazu.",
                    nalog.getTransactionId(), nalog.getPayer().getName());
        }

        log.info("Kraj ciklusa generiranja naloga.");
    }


    private String getRandomName() {
        String[] imena = {
                "Ivan", "Marija", "Ana", "Marko", "Petar", "Lucija", "Matej", "Ivana", "Luka", "Petra",
                "Stjepan", "Maja", "Filip", "Elena", "Josip", "Katarina", "Ante", "Martina", "Dino", "Nikola"
        };

        String[] prezimena = {
                "Horvat", "Kovač", "Babić", "Marić", "Novak", "Jurić", "Kovačević", "Vuković", "Knežević", "Marković",
                "Petrović", "Matić", "Tomić", "Lončar", "Filipović", "Posavec", "Radić", "Kralj", "Kušec", "Vidović"
        };

        String ime = imena[random.nextInt(imena.length)];
        String prezime = prezimena[random.nextInt(prezimena.length)];

        return ime + " " + prezime;
    }


    private String getRandomIban() {
        return "HR" + (1000000000000000000L + (long)(random.nextDouble() * 900000000000000000L));
    }
}

