package hr.fina.zadatak;

import hr.fina.zadatak.repository.KorisnikRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class TestXml {

    @Autowired
    private KorisnikRepository korisnikRepository;

    @Test
    @DisplayName("Provjera postoji li postojeći korisnik u bazi")
    void testProvjeraPostojecegKorisnika() {
        String postojeciUser = "qrq";

        int rezultat = korisnikRepository.postojiLiKorisnik(postojeciUser);

        assertTrue(rezultat > 0, "Greška: Korisnik " + postojeciUser + " nije pronađen u bazi!");
    }

    @Test
    @DisplayName("Provjera za korisnika koji sigurno NE postoji")
    void testKorisnikNePostoji() {
        String nepostojeciUser = "ovaj_korisnik_ne_postoji_123456";

        int rezultat = korisnikRepository.postojiLiKorisnik(nepostojeciUser);


        assertEquals(0, rezultat, "Greška: Pronađen je korisnik koji ne bi trebao postojati!");

    }

}
