package hr.fina.zadatak;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZadatakApplicationTests {

	@Test
	void contextLoads() {
	}

}
