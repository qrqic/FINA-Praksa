package hr.fina.zadatak;

import hr.fina.zadatak.model.Korisnik;
import hr.fina.zadatak.model.NoviKorisnikGreska;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class OsnovniTest {

    @Test
    void testKojiProlazi() {
        assertEquals(1, 1, "Ovo mora proći");
    }

    @Test
    void testKojiPada() {
        //assertEquals(1, 2, "Ovo će baciti grešku");
    }

    @Test
    void testIspravanObjekt() {
        // Kreiramo objekt sa svim podacima
        NoviKorisnikGreska ispravan = new NoviKorisnikGreska();
        ispravan.setIme("Ivan");
        ispravan.setPrezime("Horvat");
        ispravan.setUsername("ihorvat");
        ispravan.setRola("ROLE_ADMIN");

        // Provjeravamo jesu li podaci ispravno spremljeni (Asserti)
        assertNotNull(ispravan.getIme(), "Ime ne bi smjelo biti null");
        assertEquals("Ivan", ispravan.getIme());
        assertEquals("ROLE_ADMIN", ispravan.getRola());
    }

    @Test
    void testNeispravanObjekt() {
        NoviKorisnikGreska neispravan = new NoviKorisnikGreska();
        neispravan.setIme("Ivan");
        neispravan.setPrezime("Horvat");
        neispravan.setUsername("ihorvat");
        neispravan.setRola("ROLE_ADMIN");

        //assertEquals("Marko", neispravan.getIme());

    }
}
