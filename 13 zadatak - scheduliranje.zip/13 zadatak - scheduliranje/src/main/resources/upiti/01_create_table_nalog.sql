/*
SELECT * FROM payment.nalog;
*/
/*DROP TABLE payment.nalog;*/

CREATE TABLE `nalog` (
                         `transaction_Id` varchar(255) NOT NULL,
                         `amount` decimal(19,2) NOT NULL,
                         `currency` varchar(10) NOT NULL,
                         `timestamp` datetime(6) NOT NULL,
                         `payer_name` varchar(255) DEFAULT NULL,
                         `payer_iban` varchar(50) DEFAULT NULL,
                         `payee_name` varchar(255) DEFAULT NULL,
                         `payee_iban` varchar(50) DEFAULT NULL,
                         PRIMARY KEY (`transactionId`)
)