CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    enabled BOOLEAN NOT NULL
);


CREATE TABLE authorities (
    username VARCHAR(50) NOT NULL,
    authority VARCHAR(50) NOT NULL,
    CONSTRAINT fk_authorities_users
        FOREIGN KEY (username) REFERENCES users(username)
);


INSERT INTO users (username, password, enabled) VALUES
('zaposlenik', '$2a$10$QWfBv2yZlH9mSZqElYQoI.u5q4WkF0rG5pBvU7Y5Y6yFJUS6KZKDa', true),
('manager', '$2a$10$QWfBv2yZlH9mSZqElYQoI.u5q4WkF0rG5pBvU7Y5Y6yFJUS6KZKDa', true),
('admin', '$2a$10$QWfBv2yZlH9mSZqElYQoI.u5q4WkF0rG5pBvU7Y5Y6yFJUS6KZKDa', true);


INSERT INTO authorities (username, authority) VALUES
('zaposlenik', 'ROLE_ZAPOSLENIK'),
('manager', 'ROLE_MANAGER'),
('admin', 'ROLE_ADMIN');


