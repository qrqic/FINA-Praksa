package hr.fina.zadatak.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;


@Configuration //Označava klasu kao izvor definicija beans
@EnableWebSecurity //mogućuje Spring Security podršku i integraciju s Spring MVC-om
@EnableMethodSecurity //Omogućuje zaštitu na razini metoda (npr. korištenje @PreAuthorize)
public class SecurityConfiguration {

    /**
     * odrediti tko smije ući u aplikaciju, na koja vrata i pod kojim uvjetima.
     * @param http
     * @return http.build
     * @throws Exception
     */
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth
                        // 1. Javne rute i Actuator (Mora biti na vrhu!)
                        .requestMatchers("/", "/webjars/**", "/css/**", "/js/**").permitAll()
                        .requestMatchers("/actuator/**").permitAll() // POMAKNUTO GORE

                        // 2. Admin rute (samo za ROLE_ADMIN)
                        .requestMatchers("/admin/**").hasRole("ADMIN")
                        .requestMatchers("/delete/**").hasRole("ADMIN")

                        // 3. Manager/Admin rute
                        .requestMatchers("/nalozi/edit/**").hasAnyRole("MANAGER", "ADMIN")

                        // 4. Zaštićene rute (bilo koji prijavljeni korisnik)
                        .requestMatchers("/nalozi/**").authenticated()
                        .requestMatchers("/save/**", "/update/**").authenticated()

                        // 5. SVE OSTALO mora biti prijavljeno (MORA BITI ZADNJE)
                        .anyRequest().authenticated()
                )
                .httpBasic(Customizer.withDefaults())
                .formLogin(form -> form
                        .defaultSuccessUrl("/", true)
                        .permitAll()
                )
                .logout(logout -> logout
                        .logoutSuccessUrl("/")
                        .permitAll()
                );

        return http.build();
    }



    /**
     * Definira algoritam za enkripciju (hashiranje) korisničkih lozinki.
     * Koristi se BCrypt algoritam
     * @return
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

}

