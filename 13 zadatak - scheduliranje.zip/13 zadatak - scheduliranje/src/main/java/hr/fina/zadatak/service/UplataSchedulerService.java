package hr.fina.zadatak.service;

import hr.fina.zadatak.repository.PaymentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;

@Service
public class UplataSchedulerService {

    private static final Logger log = LoggerFactory.getLogger(UplataSchedulerService.class);

    private final PaymentRepository uplataRepository;

    public UplataSchedulerService(PaymentRepository uplataRepository) {
        this.uplataRepository = uplataRepository;
    }

    // Svakih 10 minuta
    @Scheduled(cron = "0 */10 * * * *")
    public void pokreniDesetominutniIzvjestaj() {
        // 1. Dohvati sumu
        BigDecimal ukupno = uplataRepository.sumirajSveUplate();
        BigDecimal iznosZaSpremanje = (ukupno != null) ? ukupno : BigDecimal.ZERO;

        log.info(">>> LOG IZVJEŠTAJ (10 min) - Ukupna suma: {} EUR", iznosZaSpremanje);

        uplataRepository.spremiSumu(iznosZaSpremanje);
    }


    // Svaki puni sat
    @Scheduled(cron = "0 0 * * * *")
    public void pokreniSatniIzvjestaj() {
        BigDecimal ukupno = uplataRepository.sumirajSveUplate();
        BigDecimal ispis = (ukupno != null) ? ukupno : BigDecimal.ZERO;

        log.info(">>> LOG IZVJEŠTAJ (1 sat) - Ukupna suma uplata: {} EUR", ispis);
    }
}
