
package hr.fina.zadatak.controller;

import hr.fina.zadatak.model.Payment;
import hr.fina.zadatak.repository.PaymentRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import hr.fina.zadatak.service.PaymentService;
import org.slf4j.LoggerFactory;
import org.springframework.web.server.ResponseStatusException;

import javax.xml.transform.stream.StreamSource;
import java.io.StringReader;
import java.math.BigDecimal;
import java.util.List;


@RestController
@RequestMapping("/api")
public class PaymentController {

    private static final Logger logger = LoggerFactory.getLogger(PaymentController.class);

    private final Jaxb2Marshaller marshaller;
    private final PaymentService paymentService;
    private final PaymentRepository paymentRepository;


    public PaymentController(Jaxb2Marshaller marshaller, PaymentService paymentService,
                             PaymentRepository paymentRepository) {
        this.marshaller = marshaller;
        this.paymentService = paymentService;
        this.paymentRepository = paymentRepository;
    }

    /**
     * Prima XML transakciju putem POST zahtjeva, validira je prema XSD shemi
     * i sprema u bazu podataka ako je ispravna.
     * Ako nije vraća grešku.
     *
     */
    @Tag(name = "Transakcije", description = "Endpointi za upravljanje uplatama")
    @Operation(
            summary = "Spremi novu XML transakciju",
            description = "Prima XML formatiranu uplatu, vrši validaciju prema XSD shemi te ju pohranjuje u relacijsku bazu podataka."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Uspješna operacija - XML je validan i podaci su spremljeni"),
            @ApiResponse(responseCode = "400", description = "Validacijska pogreška - XML ne odgovara XSD shemi ili je struktura neispravna"),
            @ApiResponse(responseCode = "500", description = "Interna pogreška sustava prilikom obrade transakcije")
    })
    @PreAuthorize("hasAnyRole('ZAPOSLENIK', 'MANAGER', 'ADMIN')") //Pristup je dopušten samo autentificiranim korisnicima koji posjeduju jednu od navedenih rola
    @PostMapping(value = "/transactions",
            consumes = MediaType.APPLICATION_XML_VALUE,
            produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> receive(@RequestBody String xml) {

        // Ispiši zaprimljeni XML (dodaj logger za ovo)
        logger.info("=== PRIMLJEN XML ===");
        logger.debug(xml);
        logger.debug("===================");

        Pair<Payment, String> paymentRazlog = validirajPaymentInitPayment(xml);

       if (paymentRazlog.getLeft() != null) {
           logger.info("Početak spremanja u bazu"); //Prosiriti info log sa detaljima transakcije, transaction id
        paymentService.save(paymentRazlog.getLeft());
           logger.info("Spremio se korisnik sa ID -> {}", paymentRazlog.getLeft().getTransactionId());
           return ResponseEntity.ok("XML je validan i uspješno zaprimljen.");
        }

        return ResponseEntity.badRequest().body("Neispravan XML prema XSD: " + paymentRazlog.getRight());
    }


    /**
     *
     * Dohvaća pojedinačnu uplatu iz baze podataka na temelju njezina ID-a
     *
     */
    @Tag(name = "Pregled pojedinačne uplate", description = "Dohvaća detaljne informacije o transakciji")
    @Operation(
            summary = "Dohvati uplatu po ID-u",
            description = "Pretražuje bazu podataka i vraća detalje transakcije na temelju proslijeđenog IDa."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Uspješno pronađena uplata",
                    content = @Content(mediaType = "application/json", schema = @Schema(implementation = Payment.class))
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Uplata s navedenim ID-om ne postoji u bazi"
            ),
            @ApiResponse(
                    responseCode = "500",
                    description = "Interna pogreška sustava"
            )
    })
    @PreAuthorize("hasAnyRole('ZAPOSLENIK', 'MANAGER', 'ADMIN')")
    @GetMapping(value = "/transaction/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Payment dohvatiUplatu(
            @Parameter(description = "Jedinstveni ID transakcije", example = "TX123456")
            @PathVariable String id) {

        // MyBatis vraća null ako zapis ne postoji u bazi
        Payment payment = paymentRepository.findById(id);

        if (payment == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "U bazi ne postoji uplata sa ID: " + id);
        }

        return payment;
    }



    /**
     * Dohvaća sve uplate iz baze podataka
     */
    @Tag(name = "Pregled pojedinačne uplate", description = "Dohvaća detaljne informacije o transakciji")
    @Operation(
            summary = "Dohvati sve uplate",
            description = "Vraća listu svih transakcija pohranjenih u sustavu."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Uspješno dohvaćena lista uplata",
                    content = @Content(
                            mediaType = "application/json",
                            array = @ArraySchema(schema = @Schema(implementation = Payment.class))
                    )
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Nije pronađena niti jedna uplata u bazi podataka"
            ),
            @ApiResponse(
                    responseCode = "500",
                    description = "Interna pogreška sustava"
            )
    })
    @PreAuthorize("hasAnyRole('ZAPOSLENIK', 'MANAGER', 'ADMIN')")
    @GetMapping(value = "/transaction/dohvatiSve", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Payment> dohvatiSve() {
        List<Payment> payments = paymentRepository.dohvatiSve();

        if (payments == null || payments.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "U bazi ne postoje korisnici");
        }

        return payments;
    }



    /**
     *
     * Dohvaća korisnike za određeni datum
     *
     */
    @Tag(name = "Pregled pojedinačne uplate", description = "Dohvaća detaljne informacije o transakciji")
    @Operation(
            summary = "Dohvati uplate za određeni datum",
            description = "Vraća listu svih transakcija izvršenih na specifičan datum proslijeđen u URL-u."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Uspješno dohvaćene uplate za navedeni datum",
                    content = @Content(
                            mediaType = "application/json",
                            array = @ArraySchema(schema = @Schema(implementation = Payment.class))
                    )
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Nisu pronađene uplate za navedeni datum"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Neispravan format datuma"
            ),
            @ApiResponse(
                    responseCode = "500",
                    description = "Interna pogreška sustava"
            )
    })
    @PreAuthorize("hasAnyRole('ZAPOSLENIK', 'MANAGER', 'ADMIN')")
    @GetMapping(value = "/transaction/dohvatiSveZaDatum/{datum}", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Payment> dohvatiSveZaDatum(
            @Parameter(
                    description = "Datum za koji se dohvaćaju uplate (format: YYYY-MM-DD)",
                    example = "2026-01-22"
            )
            @PathVariable String datum) {

        List<Payment> payments = paymentRepository.dohvatiSveZaDatum(datum);

        if (payments == null || payments.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "U bazi ne postoje uplate za datum: " + datum);
        }

        return payments;
    }



    /**
     *
     * Brise korisnike
     *
     */
    @Tag(name = "Brisanje zapisa", description = "Trajno uklanja podatke o transakciji/korisniku iz sustava.")
    @Operation(
            summary = "Izbriši korisnika/transakciju po ID-u",
            description = "Uklanja podatke o transakciji ili korisniku iz baze podataka na temelju proslijeđenog ID-a."
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Uspješno izbrisano"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Zapis s navedenim ID-om nije pronađen"
            ),
            @ApiResponse(
                    responseCode = "500",
                    description = "Interna pogreška prilikom brisanja"
            )
    })
    @PreAuthorize("hasAnyRole('ADMIN')")
    @DeleteMapping("/transaction/izbrisiKorisnika/{id}")
    public void izbrisiKorisnika(
            @Parameter(description = "ID korisnika ili transakcije koju treba obrisati", example = "TX123456")
            @PathVariable String id) {

        int brisi = paymentRepository.izbrisiKorisnika(id);

        if (brisi != 0) {
            logger.info("Korisnik je uspjesno izbrisan s ID: {}", id);
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Korisnik s ID-om " + id + " ne postoji.");
        }
    }



    /**
     *
     * Metoda azurira korisnika po ID i mijenja amount vrijednost.
     *
     */
    @Tag(name = "Izmjena transakcije", description = "Ažurira korisnika u sustavu.")
    @Operation(
            summary = "Ažuriraj iznos transakcije",
            description = "Mijenja iznos postojeće transakcije na temelju njezinog ID-a."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Iznos uspješno ažuriran"),
            @ApiResponse(responseCode = "404", description = "Transakcija s navedenim ID-om nije pronađena"),
            @ApiResponse(responseCode = "400", description = "Neispravni ulazni podaci"),
            @ApiResponse(responseCode = "500", description = "Interna pogreška pri ažuriranju")
    })
    @PreAuthorize("hasAnyRole('MANAGER', 'ADMIN')")
    @PutMapping("/transaction/azurirajKorisnika_{id}/{amount}")
    public void azurirajKorisnika(
            @Parameter(description = "ID transakcije koju treba ažurirati", example = "TX123456")
            @PathVariable String id,
            @Parameter(description = "Novi iznos transakcije", example = "150.50")
            @PathVariable BigDecimal amount) {

        int azuriraj = paymentRepository.azurirajKorisnika(id, amount);

        if (azuriraj != 0) {
            logger.info("Transakcija {} je uspjesno azurirana na iznos {}", id, amount);
        } else {
            logger.warn("Transakcija s ID-om {} nije pronađena.", id);
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Transakcija s ID-om " + id + " nije pronađena.");
        }
    }

    private Pair<Payment, String> validirajPaymentInitPayment(String xml) {

        Payment payment = null;
        String reason = null;
        try {
            // VALIDACIJA PO XSD-U
            payment = (Payment)  marshaller.unmarshal(new StreamSource(new StringReader(xml)));

            // Ako smo došli ovdje → XML je VALIDAN
            logger.info("✅ XML JE VALIDAN PO XSD-u");
            logger.debug("========= PAYMENT OBJECT =========");
            logger.debug(String.valueOf(payment));

        } catch (Exception e) {
            Throwable cause = e;
            while (cause.getCause() != null) {
                cause = cause.getCause();
            }

            reason = cause.getMessage();

            logger.error("❌ XML NIJE VALIDAN");
            logger.error(reason);

            return Pair.of(payment, reason);
        }

        return Pair.of(payment,reason);
    }

}
