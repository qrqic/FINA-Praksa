package hr.fina.zadatak.model;

import java.time.LocalDateTime;

public class KorisnikGreska {
    private int id;
    private String korisnik;
    private String opisGreske;
    private LocalDateTime vrijemeDogadaja;

    public KorisnikGreska(int id, String korisnik, String opisGreske) {
        this.id = id;
        this.korisnik = korisnik;
        this.opisGreske = opisGreske;
        this.vrijemeDogadaja = LocalDateTime.now();
    }

    public String getKorisnik() {
        return korisnik;
    }

    public void setKorisnik(String korisnik) {
        this.korisnik = korisnik;
    }

    public String getOpisGreske() {
        return opisGreske;
    }

    public void setOpisGreske(String opisGreske) {
        this.opisGreske = opisGreske;
    }

    public LocalDateTime getVrijemeDogadaja() {
        return vrijemeDogadaja;
    }

    public void setVrijemeDogadaja(LocalDateTime vrijemeDogadaja) {
        this.vrijemeDogadaja = vrijemeDogadaja;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
