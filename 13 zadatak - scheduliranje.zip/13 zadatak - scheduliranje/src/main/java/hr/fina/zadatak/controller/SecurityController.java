package hr.fina.zadatak.controller;


import hr.fina.zadatak.model.NoviKorisnikGreska;
import hr.fina.zadatak.model.Payment;
import hr.fina.zadatak.repository.KorisnikRepository;
import hr.fina.zadatak.repository.PaymentRepository;
import jakarta.validation.constraints.Email;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.time.LocalDateTime;




@Controller
public class SecurityController {
    private LocalDateTime timestamp;
    private final PaymentRepository paymentRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    private KorisnikRepository korisnikRepository;

    public SecurityController(PaymentRepository paymentRepository,  KorisnikRepository korisnikRepository, PasswordEncoder passwordEncoder) {
        this.paymentRepository = paymentRepository;
        this.korisnikRepository = korisnikRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/")
    public String home(Model model) {
        // "naslov" je ključ koji koristiš u HTML-u,
        // a drugi parametar je stvarna vrijednost.
        model.addAttribute("naslov", "Dobrodošli u TRACON aplikaciju!");
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        model.addAttribute("naslovPrijava", "Dobrodošao " + username + "!");
        model.addAttribute("name", username);
        return "index"; // Spring traži index.html u /templates/
    }

    @GetMapping("/nalozi")
    public String user(Model model,
                       @RequestParam(defaultValue = "0") int page,
                       @RequestParam(defaultValue = "15") int size) { // Promjena na 15

        int offset = page * size;
        List<Payment> nalozi = paymentRepository.dohvatiPaginirano(size, offset);
        long totalElements = paymentRepository.countSve();

        // Izračunaj ukupan broj stranica (npr. 46 naloga / 15 = 4 stranice)
        int totalPages = (int) Math.ceil((double) totalElements / size);

        model.addAttribute("nalozi", nalozi);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", totalPages);
        model.addAttribute("size", size);

        if (!model.containsAttribute("noviNalog")) {
            model.addAttribute("noviNalog", new Payment());
        }
        return "nalozi";
    }




    @PostMapping("/save")
    public String spremiNalog(@ModelAttribute("noviNalog") Payment nalog) {
        // Postavi trenutno vrijeme
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        nalog.setTimestamp(java.time.LocalDateTime.now());

        // Poziv MyBatis inserta
        paymentRepository.save(nalog);

        // Vraća te na istu stranicu da vidiš novi red u tablici
        return "redirect:/nalozi";
    }

    @PostMapping("/delete")
    public String deleteNalog(@RequestParam("transactionId") String id) {
        paymentRepository.izbrisiKorisnika(id);
        return "redirect:/nalozi";
    }

    // 1. Klik na gumb "Uredi" nas vraća na /tablice ali s popunjenom formom
    @GetMapping("/nalozi/edit/{id}")
    public String urediNalog(@PathVariable("id") String id, Model model) {
        // Ime i lista naloga (isto kao u običnom /tablice)
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        model.addAttribute("name", username);
        model.addAttribute("nalozi", paymentRepository.dohvatiSve());

        // Dohvaćamo postojeći nalog umjesto novog
        Payment postojeci = paymentRepository.findById(id);
        model.addAttribute("noviNalog", postojeci);

        return "nalozi";
    }

    // 2. Obrada Update-a
    @PostMapping("/update")
    public String update(@ModelAttribute("noviNalog") Payment nalog) {
        nalog.setTimestamp(java.time.LocalDateTime.now());
        paymentRepository.azurirajTablicu(nalog);
        return "redirect:/nalozi";
    }


    @PostMapping("/admin/spremi")
    public String spremiKorisnika(@ModelAttribute("noviKorisnik") NoviKorisnikGreska korisnik) {

        String rawPassword = korisnik.getPassword();
        String encodedPassword = passwordEncoder.encode(rawPassword);
        korisnik.setPassword(encodedPassword);

        int brojKorisnika = korisnikRepository.postojiLiKorisnik(korisnik.getUsername());
        if (brojKorisnika > 0) {
            return "redirect:/admin?error=exists";
        }

        korisnikRepository.dodajKorisnika(korisnik);
        return "redirect:/admin?success";
    }

    @GetMapping("/admin") //
    public String prikaziAdminPanel(Model model) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        model.addAttribute("name", username);

        // Dohvaćamo trenutne vrijednosti iz baze da ih Admin vidi u poljima
        model.addAttribute("genBroj", paymentRepository.dohvatiVrijednostParametra("GEN_BROJ_NALOGA"));
        model.addAttribute("genGreska", paymentRepository.dohvatiVrijednostParametra("GEN_STOPA_GRESKE"));

        model.addAttribute("name", username);

        return "admin";
    }

    @PostMapping("/admin/generator/update")
    public String updateGenerator(@RequestParam String brojNaloga, @RequestParam String stopaGreske) {
        paymentRepository.updateParametar("GEN_BROJ_NALOGA", brojNaloga);
        paymentRepository.updateParametar("GEN_STOPA_GRESKE", stopaGreske);
        return "redirect:/admin?genSuccess=true";
    }





}
