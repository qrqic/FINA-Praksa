package hr.fina.zadatak.service;

import hr.fina.zadatak.model.Payment;
import hr.fina.zadatak.repository.PaymentRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;

/**
 * Servisni sloj za obradu platnih transakcija i poslovnu logiku.
 */
@Service
public class PaymentService {

    private final PaymentRepository paymentRepository;

    public PaymentService(PaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }

    /** Dohvaća plaćanje prema ID-u.*/
    @Transactional(readOnly = true)
    public Payment findById(String id) {
        return paymentRepository.findById(id);
    }

    /** Pohranjuje novu transakciju u bazu. */
    @Transactional
    public void save(Payment payment) {
        paymentRepository.save(payment);
    }

    /** Pokreće dohvat svih transakcija. */
    @Transactional
    public void dohvatiSve(){
        paymentRepository.dohvatiSve();
    }

    /** Dohvaća transakcije za određeni datum. */
    @Transactional
    public void dohvatiSveZaDatum(String datum){
        paymentRepository.dohvatiSveZaDatum(datum);
    }

    /** Briše zapis i baca 404 ako ID ne postoji. */
    @Transactional
    public void izbrisiKorisnika(String id) {
        int obrisano = paymentRepository.izbrisiKorisnika(id);
        if (obrisano == 0) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Korisnik s ID-om " + id + " ne postoji.");
        }
    }

    /** Ažurira iznos transakcije za zadani ID. */
    @Transactional
    public void azurirajKorisnika(String id, BigDecimal amount) {
        paymentRepository.azurirajKorisnika(id, amount);
    }

}
