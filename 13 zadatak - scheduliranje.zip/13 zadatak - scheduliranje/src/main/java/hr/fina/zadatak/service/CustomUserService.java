package hr.fina.zadatak.service;

import hr.fina.zadatak.model.Korisnik;
import hr.fina.zadatak.model.NoviKorisnikGreska;
import hr.fina.zadatak.repository.KorisnikRepository;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

/**
 * Servis koji omogućuje Spring Securityju dohvat korisničkih podataka iz baze.
 * @author dgrgic
 */
@Service
public class CustomUserService implements UserDetailsService { //implementira standardno Spring Security sučelje

    private final KorisnikRepository repo; // Injection repozitorija za izvršavanje SQL upita

    public CustomUserService(KorisnikRepository repo) {
        this.repo = repo;
    }

    /**
     * Ovu metodu Spring Security poziva automatski čim korisnik upiše korisničko ime u login formu.
     * @param username
     * @return
     */
    @Override
    public UserDetails loadUserByUsername(String username) {
        NoviKorisnikGreska k = repo.findByKorisnickoIme(username); //traži korisnika u bazi

        if (k == null) { //Ako korisnika nema izbaci Exception
            throw new UsernameNotFoundException("Nema korisnika");
        }
        /**
         * Ako je k!=0 onda vrati klasu Korisnik koja se prvo mora pretvoriti u UserDetails objekt koji Spring razumije
         */


        // Provjera ako je password slučajno null (problem u XML-u)
        if (k.getPassword() == null) {
            System.out.println("KRITIČNO: Lozinka iz baze je NULL! Provjerite MyBatis XML mapiranje.");
        }

        return User
                .withUsername(k.getUsername())
                .password(k.getPassword())
                .authorities(k.getRola())
                .build();
    }
}
