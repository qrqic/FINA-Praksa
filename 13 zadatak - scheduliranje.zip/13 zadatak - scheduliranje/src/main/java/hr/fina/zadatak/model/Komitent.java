package hr.fina.zadatak.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@Embeddable
@XmlRootElement(name = "komitent")
@XmlAccessorType(XmlAccessType.FIELD)
public class Komitent {

    @Column(name = "payer_name")
    @XmlElement(required = true)
    private String name;
    @Column(name = "payer_iban")
    @XmlElement(required = true)
    private String iban;

    // Konstruktori
    public Komitent() {}

    public Komitent(String name, String iban) {
        this.name = name;
        this.iban = iban;
    }

    // Getteri i Setteri
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getIban() { return iban; }
    public void setIban(String iban) { this.iban = iban; }

    @Override
    public String toString() {
        return "Komitent{" +
                "name='" + name + '\'' +
                ", iban='" + iban + '\'' +
                '}';
    }
}
