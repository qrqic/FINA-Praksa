package hr.fina.zadatak.util;

import jakarta.xml.bind.annotation.adapters.XmlAdapter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Ova greška se događa zato što JAXB ne zna kako raditi s modernim Java 8+ tipovima podataka, kao što je java.time.LocalDateTime.
 * Nema praznog konstruktora: JAXB radi pomoću refleksije i zahtijeva da svaka klasa ima prazan konstruktor (default constructor)
 * kako bi mogao kreirati objekt prije nego što ga popuni podacima iz XML-a. LocalDateTime je immutable klasa i nema prazan
 * konstruktor (objekt se stvara preko LocalDateTime.now() ili .of()).
 * JAXB je "star": Iako koristiš verziju iz 2026. godine, osnovni JAXB standard je nastao prije java.time paketa.
 * On "out-of-the-box" podržava samo stare tipove poput java.util.Date ili java.util.Calendar.
 */

public class LocalDateTimeAdapter extends XmlAdapter<String, LocalDateTime> {
    private final DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    @Override
    public LocalDateTime unmarshal(String v) {
        return LocalDateTime.parse(v, formatter);
    }

    @Override
    public String marshal(LocalDateTime v) {
        return v.format(formatter);
    }
}