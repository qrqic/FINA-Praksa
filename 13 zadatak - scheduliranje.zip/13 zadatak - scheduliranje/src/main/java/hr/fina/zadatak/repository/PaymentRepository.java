package hr.fina.zadatak.repository;

import hr.fina.zadatak.model.Payment;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

/**
 * Repozitorij za upravljanje plaćanjima putem MyBatisa.
 * @author dgrgic
 */
@Repository
@Mapper
public interface PaymentRepository {

     /** Dohvaća uplatu prema ID-u. */
     Payment findById(String id);

     /** Sprema novu uplatu. */
     void save(Payment payment);

     /** Dohvaća sve uplate iz baze. */
     List<Payment> dohvatiSve();

     /** Dohvaća uplate za specifičan datum. */
     List<Payment> dohvatiSveZaDatum(String datum);

     /** Briše zapis prema ID-u. Vraća 0 ili 1 (true ili false)*/
     int izbrisiKorisnika(String id);

     /** Ažurira iznos uplate za zadani ID. */
     int azurirajKorisnika(@Param("id") String id, @Param("amount") BigDecimal amount);

     /**
      * Ažurira postojeći nalog u bazi
      * @param nalog Objekt Payment s novim podacima
      */
     void azurirajTablicu(Payment nalog);

     BigDecimal sumirajSveUplate();

     void spremiSumu(BigDecimal suma);

     String dohvatiVrijednostParametra(@Param("kljuc") String kljuc);

     void updateParametar(@Param("kljuc") String kljuc, @Param("vrijednost") String vrijednost);

     List<Payment> dohvatiPaginirano(@Param("size") int size, @Param("offset") int offset);

     long countSve();
}
