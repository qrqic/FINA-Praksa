package hr.fina.zadatak.model;

import hr.fina.zadatak.util.LocalDateTimeAdapter;
import jakarta.persistence.*; // DODANO: Za bazu podataka
import jakarta.xml.bind.annotation.*;
import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity // DODANO: Označava klasu kao JPA entitet
@Table(name = "nalog") // DODANO: Mapira na tablicu 'payment' u MySQL-u
@XmlRootElement(name = "transaction")
@XmlAccessorType(XmlAccessType.FIELD)
public class Payment{

    @Id // DODANO: Označava primarni ključ
    @Column(name = "transactionId") // Mapiranje na naziv stupca u bazi
    @XmlElement(required = true)
    private String transactionId;

    @Column(name = "amount")
    @XmlElement(required = true)
    private BigDecimal amount;

    @Column(name = "currency")
    @XmlElement(required = true)
    private String currency;

    @Column(name = "timestamp")
    @XmlElement(required = true)
    @XmlJavaTypeAdapter(LocalDateTimeAdapter.class)
    private LocalDateTime timestamp;


    @Embedded // JPA ce ugraditi polja iz Komitent klase ovdje
    @AttributeOverrides({
            @AttributeOverride(name = "name", column = @Column(name = "payer_name")),
            @AttributeOverride(name = "iban", column = @Column(name = "payer_iban"))
    })
    @XmlElement(required = true)
    private Komitent payer;

    @Embedded // JPA ce ugraditi polja iz Komitent klase ovdje
    @AttributeOverrides({
            @AttributeOverride(name = "name", column = @Column(name = "payee_name")),
            @AttributeOverride(name = "iban", column = @Column(name = "payee_iban"))
    })
    @XmlElement(required = true)
    private Komitent payee;

    // Konstruktori
    public Payment() {
        this.payer = new Komitent(); // Osigurava da polje nije null u formi
        this.payee = new Komitent();
    }

    // Getteri i Setteri
    public String getTransactionId() { return transactionId; }
    public void setTransactionId(String transactionId) { this.transactionId = transactionId; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }

    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    public Komitent getPayer() { return payer; }
    public void setPayer(Komitent payer) { this.payer = payer; }

    public Komitent getPayee() { return payee; }
    public void setPayee(Komitent payee) { this.payee = payee; }

    @Override
    public String toString() {
        return "Payment{" +
                "transactionId='" + transactionId + '\'' +
                ", amount=" + amount +
                ", currency='" + currency + '\'' +
                ", timestamp=" + timestamp +
                ", payer=" + payer +
                ", payee=" + payee +
                '}';
    }
}


/**
 * Pomoćna klasa za partyType (vanjska klasa unutar istog dokumenta ili zasebna datoteka)
 */

/*
@XmlAccessorType(XmlAccessType.FIELD)
class PartyType {
    @XmlElement(required = true)
    private String name;

    @XmlElement(required = true)
    private String iban;

    public PartyType() {}

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getIban() { return iban; }
    public void setIban(String iban) { this.iban = iban; }

    @Override
    public String toString() {
        return "PartyType{" + "name='" + name + '\'' + ", iban='" + iban + '\'' + '}';
    }

}
*/