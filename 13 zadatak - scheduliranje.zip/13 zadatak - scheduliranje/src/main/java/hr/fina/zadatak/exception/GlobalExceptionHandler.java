package hr.fina.zadatak.exception;

import hr.fina.zadatak.model.NoviKorisnikGreska;
import hr.fina.zadatak.repository.GreskaRepository;
import hr.fina.zadatak.repository.KorisnikRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.RestTemplate;


@ControllerAdvice
public class GlobalExceptionHandler {
    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);
    @Autowired
    private GreskaRepository greskaRepository;

    @Autowired
    private KorisnikRepository  korisnikRepository;

    @Autowired
    private RestTemplate restTemplate;

    /**
     * Kada sustav baci {@link AccessDeniedException} (npr. zbog @PreAuthorize),
     * ova metoda preuzima kontrolu i vraća prilagođeni odgovor klijentu u ovom slučaju izbacuje logger.error
     *
     * @return odgovor s porukom o zabrani pristupa (u POSTMANU)
     */
    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<String> handleAccessDeniedException(AccessDeniedException ex) {
        // Dohvaćamo ime korisnika koji je pokušao neovlaštenu akciju
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        String opis = "Pokušaj neovlaštenog pristupa: " + ex.getMessage();

        //Dohvacanje admina
        String admin = korisnikRepository.findbyAdminRole().getUsername();

        // Ispisujemo ERROR log u konzolu
        logger.error("!!! SIGURNOSNI PREKRŠAJ !!! Korisnik '{}' je pokušao pristupiti zabranjenoj ruti.", username);
        logger.info("Ovo je mail " + username);
        //Spremanje u bazu
        greskaRepository.spremiGresku(username, opis);

        try {
            restTemplate.postForEntity("http://localhost:8081/api/notifikacije/sigurnosni-prekrsaj", username, String.class);
        } catch (Exception e) {
            logger.error("Neuspjelo slanje obavijesti notification-servisu: {}", e.getMessage());
        }

        // Vraćamo odgovor klijentu (Postmanu)
        return ResponseEntity
                .status(HttpStatus.FORBIDDEN)
                .body("Nemate ovlasti za ovu operaciju. Vaš pokušaj je zabilježen.");
    }
}
