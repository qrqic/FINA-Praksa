package hr.fina.zadatak.config;

import hr.fina.zadatak.model.Komitent;
import hr.fina.zadatak.model.Payment;
import jakarta.xml.bind.Marshaller;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class PaymentJaxbConfig {

    // Putanja do XSD datoteke iz lokacije
    @Value("${schema.location}")
    private Resource schemaResource;

    @Bean
    public Jaxb2Marshaller marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();

        // ✅ Postavljanje klasa koje JAXB treba prepoznati
        marshaller.setClassesToBeBound(
                Payment.class,
                Komitent.class
        );

        // ✅ XSD validacija (provjerava XML prema shemi prilikom marshallinga)
        if (schemaResource.exists()) {
            marshaller.setSchema(schemaResource);
        }

        // ✅ Konfiguracija Marshaller svojstava (npr. lijep ispis)
        Map<String, Object> properties = new HashMap<>();
        properties.put(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        properties.put(Marshaller.JAXB_ENCODING, "UTF-8");

        marshaller.setMarshallerProperties(properties);

        return marshaller;
    }
}
