package hr.fina.zadatak.model;


public class NoviKorisnikGreska {
    private String ime;
    private String prezime;
    private String username;
    private String password;
    private String rola;

    public NoviKorisnikGreska(String ime, String prezime, String username, String password, String rola, String opisGreske) {
        this.ime = ime;
        this.prezime = prezime;
        this.username = username;
        this.password = password;
        this.rola = rola;
    }

    public NoviKorisnikGreska() {
    }


    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRola() {
        return rola;
    }

    public void setRola(String rola) {
        this.rola = rola;
    }
}
