
package hr.fina.zadatak;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@EnableScheduling
public class ZadatakApplication {
    /**
     * Glavna metoda koja pokreće aplikaciju.
     * @param args
     */
    public static void main(String[] args) {
        SpringApplication.run(ZadatakApplication.class, args);
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
