package hr.fina.zadatak.repository;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface GreskaRepository {
    void spremiGresku(String korisnik, String opis);
}
