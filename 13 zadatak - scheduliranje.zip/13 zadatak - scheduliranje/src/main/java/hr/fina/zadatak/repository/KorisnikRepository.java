package hr.fina.zadatak.repository;

import hr.fina.zadatak.model.Korisnik;
import hr.fina.zadatak.model.NoviKorisnikGreska;
import org.apache.ibatis.annotations.Mapper;

/**
 * Sučelje za upravljanje podacima o korisnicima u bazi podataka.
 * Koristi MyBatis {@code @Mapper} za mapiranje SQL upita na metode sučelja.
 * @author dgrgic
 */
@Mapper
public interface KorisnikRepository {
    NoviKorisnikGreska findByKorisnickoIme(String korisnickoIme);
    NoviKorisnikGreska findbyAdminRole();
    void dodajKorisnika(NoviKorisnikGreska korisnik);
    int postojiLiKorisnik(String username);
}

